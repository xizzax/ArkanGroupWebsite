function OilGas(){
    return (
        <h1>oil gas page</h1>
    );
}

export default OilGas;