function Fertilizer(){
    return (
        <h1>Fertilizers page</h1>
    );
}

export default Fertilizer;