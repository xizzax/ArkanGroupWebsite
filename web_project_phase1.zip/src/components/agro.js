function Agro(){
    return (
        <h1>agro page</h1>
    );
}

export default Agro;