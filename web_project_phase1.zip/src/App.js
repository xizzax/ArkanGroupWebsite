//include react bootstrap css
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Index from "./components/index_page";


function App() {
  return <Index/>;
}

export default App;
